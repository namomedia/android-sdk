Library Project including Namo client jar and resources.

This can be used by an Eclipse Android project to use the API's 
provided by Namo.

There is technically no source, but the src folder is necessary
to ensure that the build system works. The content is actually
located in the libs/ directory.


USAGE:

Make sure you import this Android library project into your IDE
and set this project as a dependency.

See http://docs.namomedia.com/android for instructions on using
other builds systems, such as Maven or Gradle.