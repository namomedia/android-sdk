package com.namomedia.android;

// Stub java file to make inclusion into some IDE's (Eclipse) work when
// importing the final library project. The compiled Namo source
// code is packaged as a jar file in your libs directory.
public final class UnusedStub {
    private UnusedStub() { }
}
