package com.namomedia.android;

// Stub java file to make inclusion into some IDE's work.
public final class UnusedStub {
    private UnusedStub() { }
}
